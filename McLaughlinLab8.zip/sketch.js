let dawgImg, shrekImg;

function preload() {
  dawgImg = loadImage('https://i.postimg.cc/SKx5PzpG/IghtDawg.png');
  shrekImg = loadImage('https://i.postimg.cc/FRf6r5zd/Shrek-Grin.jpg');
}

function setup() {
  createCanvas(400, 400);
  textFont('Arial');
}

function draw() {
  background(220);

  image(dawgImg, mouseX, 50, 100, 100);
  image(shrekImg, 200, 200, 100, mouseY);

  stroke(0);
  fill(50, 150, 200);
  textSize(20);
  text('Real and True', 50, 300, 300, 50);
}
