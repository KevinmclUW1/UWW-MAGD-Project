function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);  

 
  for (let i = 0; i < 5; i++) {
    push();  // Save current state
    translate(80 * i + 50, height / 2); 
    scale(0.5 + i * 0.2);  
    rotate(i * 20);  
    drawSpaceship(); 
    pop(); 
  }

  print("Canvas width: " + getCanvasWidth());
}

function drawSpaceship() {
fill(150);  
  triangle(-10, 20, 10, 20, 0, -20);  

  fill(255, 0, 0);  
  ellipse(-8, 20, 5, 10);  
  ellipse(8, 20, 5, 10);  

  fill(255); 
  ellipse(0, -10, 10, 10);  
}

function getCanvasWidth() {
  return width; 
}